import telebot
from telebot import types
import defs, secrets, json, requests, random, base64


tokenss = ""
bot = telebot.TeleBot(tokenss)


uu1 = defs.uu()
uu2 = defs.uu()
uu3 = defs.uu()
ind = "android-" + secrets.token_hex(8)
mids = defs.mid()



def sendmil(email):
    global uu1,uu2,uu3,ind,mids
    hdhd = {
  'User-Agent': "Instagram 237.0.0.14.102 Android (31/12; 440dpi; 1080x2179; Xiaomi/POCO; M2102J20SG; vayu; qcom; ar_EG_#u-nu-latn; 373310554)",
  'x-ig-app-locale': "ar_EG_#u-nu-latn",
  'x-ig-device-locale': "ar_EG_#u-nu-latn",
  'x-ig-mapped-locale': "ar_AR",
  'x-pigeon-session-id': "UFS-ae86a2be-2ab3-48d5-9b69-f254bd6e76e5-1",
  'x-pigeon-rawclienttime': str(defs.tm()),
  'x-ig-bandwidth-speed-kbps': "906.000",
  'x-ig-bandwidth-totalbytes-b': "0",
  'x-ig-bandwidth-totaltime-ms': "0",
  'x-ig-app-startup-country': "IQ",
  'x-bloks-version-id': "8dab28e76d3286a104a7f1c9e0c632386603a488cf584c9b49161c2f5182fe07",
  'x-ig-www-claim': "0",
  'x-bloks-is-layout-rtl': "true",
  'x-ig-device-id': str(uu2),
  'x-ig-family-device-id': str(uu1),
  'x-ig-android-id': str(ind),
  'x-ig-timezone-offset': "10800",
  'x-ig-nav-chain': "ADf:landing_facebook:1:button::,ADe:email_or_phone:3:button::",
  'x-fb-connection-type': "WIFI",
  'x-ig-connection-type': "WIFI",
  'x-ig-capabilities': "3brTv10=",
  'x-ig-app-id': "567067343352427",
  'priority': "u=3",
  'accept-language': "ar-EG, en-US",
  'x-mid': str(mids),
  'ig-intended-user-id': "0",
  'x-fb-http-engine': "Liger",
  'x-fb-client-ip': "True",
  'x-fb-server-cluster': "True"}
    url = "https://i.instagram.com/api/v1/accounts/send_verify_email/"
    data = {
        "phone_id": str(uu1),
        "guid": str(uu2),
        "device_id": str(ind),
        "email": str(email),
        "waterfall_id": str(uu3),
        "auto_confirm_only": "false"}
    
    payload = {"signed_body": f"SIGNATURE.{json.dumps(data, separators=(',', ':'))}"}
    
    try:
        r = requests.post(url, data=payload, headers=hdhd)
        if 'email_sent":true' in r.text:
            return True
    except:
        return False




def sendcod(email,code):
    global uu1,uu2,uu3,ind,mids
    url = "https://i.instagram.com/api/v1/accounts/check_confirmation_code/"
    data = {
        "code": str(code),
        "device_id": str(ind),
        "email": str(email),
        "waterfall_id": str(uu3)}
    payload = {"signed_body": f"SIGNATURE.{json.dumps(data, separators=(',', ':'))}"}
    headers = {
      'User-Agent': "Instagram 237.0.0.14.102 Android (31/12; 440dpi; 1080x2179; Xiaomi/POCO; M2102J20SG; vayu; qcom; ar_EG_#u-nu-latn; 373310554)",
      'x-ig-app-locale': "ar_EG_#u-nu-latn",
      'x-ig-device-locale': "ar_EG_#u-nu-latn",
      'x-ig-mapped-locale': "ar_AR",
      'x-pigeon-session-id': "UFS-ae86a2be-2ab3-48d5-9b69-f254bd6e76e5-4",
      'x-pigeon-rawclienttime': str(defs.tm()),
      'x-ig-bandwidth-speed-kbps': "906.000",
      'x-ig-bandwidth-totalbytes-b': "0",
      'x-ig-bandwidth-totaltime-ms': "0",
      'x-ig-app-startup-country': "IQ",
      'x-bloks-version-id': "8dab28e76d3286a104a7f1c9e0c632386603a488cf584c9b49161c2f5182fe07",
      'x-ig-www-claim': "0",
      'x-bloks-is-layout-rtl': "true",
      'x-ig-device-id': str(uu2),
      'x-ig-family-device-id': str(uu1),
      'x-ig-android-id': str(ind),
      'x-ig-timezone-offset': "10800",
      'x-ig-nav-chain': "ADf:landing_facebook:1:button::,ADe:email_or_phone:3:button::,ADe:email_or_phone:5:button::,ADe:email_or_phone:6:button::,9oX:email_verify:7:button::",
      'x-fb-connection-type': "WIFI",
      'x-ig-connection-type': "WIFI",
      'x-ig-capabilities': "3brTv10=",
      'x-ig-app-id': "567067343352427",
      'priority': "u=3",
      'accept-language': "ar-EG, en-US",
      'x-mid': str(mids),
      'ig-intended-user-id': "0",
      'x-fb-http-engine': "Liger",
      'x-fb-client-ip': "True",
      'x-fb-server-cluster': "True"}
    r = requests.post(url, data=payload, headers=headers)
    if "signup_code" in r.text:
        return True, r.json()["signup_code"]
    else:
        return False, False
    
def finsh(email,codesgan):
    global uu1,uu2,uu3,ind,mids
    
    pas="bazoka"
    username=defs.username()
    nemas=defs.name()

    url = "https://i.instagram.com/api/v1/accounts/create/"
    data = {
        "is_secondary_account_creation": "false",
        "jazoest": "22611",
        "tos_version": "row",
        "suggestedUsername": "",
        "allow_contacts_sync": "true",
        "sn_result": "API_ERROR: class X.ANw:7: ",
        "do_not_auto_login_if_credentials_match": "true",
        "phone_id": str(uu1),
        "enc_password": "#PWD_INSTAGRAM:4:1755270147:Af7th42uJu5bqZu4aSoAAX8soffGaSxwxLn2NoRItwgEnLrrNC+8Be83cYoYYqc7MLqvkzHPj5InmTDmWMRMycBzhWbG4dQJf00VvtEspWAjdGvIo8Gu4PU63hhjOonZUvk7E885KhLv18CN3g3dlywqo8XkgL666B6aMFhKkoeTODeSIdbIJ98IKnS4qYyowk1CfrSwGLW0Ray+VEsYpFTvcBaGnHt9nvD7Pf9avk2b5SUiyECzi5Q1OErJdM6GQeuQYL3p9uElWMkmGtxXiwoC6ZwxbprnX+m6mYippyy8wx4BfQSONDMa2w9A7LCgVz/cfNYaJg8ZeTxw63k8u2iu6p/ioJKcdAZ6CuUQZ9dSbgjtn4DGMoYKb1DFDA2liVsSI5hb",
        "username": str(username),
        "first_name": str(nemas),
        "day": str(random.randint(1, 31)),
        "adid": "00000000-0000-0000-0000-000000000000",
        "guid": str(uu2),
        "year": "1999",
        "device_id": str(ind),
        "_uuid": str(uu2),
        "email": str(email),
        "month": str(random.randint(1, 12)),
        "sn_nonce": "NTliZmUyYmMwZUBlbWFpbHd3dy5wcm98MTc1NTI2OTk5MHyNQcyaWS/i2/cgQhOKhBKZPE/ayhjiwxc=",
        "force_sign_up_code": str(codesgan),
        "waterfall_id": str(uu3),
        "qs_stamp": "",
        "one_tap_opt_in": "true"}    
    payload = {"signed_body": f"SIGNATURE.{json.dumps(data, separators=(',', ':'))}"}
        
    headers = {
      'User-Agent': "Instagram 237.0.0.14.102 Android (31/12; 440dpi; 1080x2179; Xiaomi/POCO; M2102J20SG; vayu; qcom; ar_EG_#u-nu-latn; 373310554)",
      'x-ig-app-locale': "ar_EG_#u-nu-latn",
      'x-ig-device-locale': "ar_EG_#u-nu-latn",
      'x-ig-mapped-locale': "ar_AR",
      'x-pigeon-session-id': "UFS-3cee8c2e-f506-46e9-a861-2971ac785a1a-5",
      'x-pigeon-rawclienttime': str(defs.tm),
      'x-ig-bandwidth-speed-kbps': "906.000",
      'x-ig-bandwidth-totalbytes-b': "0",
      'x-ig-bandwidth-totaltime-ms': "0",
      'x-ig-app-startup-country': "IQ",
      'x-bloks-version-id': "8dab28e76d3286a104a7f1c9e0c632386603a488cf584c9b49161c2f5182fe07",
      'x-ig-www-claim': "0",
      'x-bloks-is-layout-rtl': "true",
      'x-ig-device-id': str(uu2),
      'x-ig-family-device-id': str(uu1),
      'x-ig-android-id': str(ind),
      'x-ig-timezone-offset': "10800",
      'x-ig-nav-chain': "ADf:landing_facebook:1:button::,ADe:email_or_phone:2:button::,9oX:email_verify:3:button::,A8Y:one_page_registration:4:button::,A8Y:one_page_registration:5:button::,A9I:add_birthday:6:button::,A9I:add_birthday:7:button::,A8v:username_sign_up:8:button::,A8v:username_sign_up:9:button::",
      'x-fb-connection-type': "WIFI",
      'x-ig-connection-type': "WIFI",
      'x-ig-capabilities': "3brTv10=",
      'x-ig-app-id': "567067343352427",
      'priority': "u=3",
      'accept-language': "ar-EG, en-US",
      'x-mid': str(mids),
      'ig-intended-user-id': "0",
      'x-fb-http-engine': "Liger",
      'x-fb-client-ip': "True",
      'x-fb-server-cluster': "True"}
    r = requests.post(url, data=payload, headers=headers)
    if '"message":"يرجى الانتظار لبضع دقائق قبل إعادة المحاولة."' in r.text:
        return False, "vpn"
    elif '"account_created":true' in r.text:
        token=r.headers.get("ig-set-authorization")
        session=json.loads(base64.b64decode(token.split(":")[2]).decode("utf-8")).get("sessionid")
        return True,{
        "username":username,
        "name":nemas,
        "password":pas,
        "session":session,
        "token":token}
    else:
        return False,False
        
        

@bot.message_handler(commands=['start'])
def start_msg(message):
    bot.reply_to(message, "مرحباً! أرسل بريدك الإلكتروني للبدء.")

@bot.message_handler(func=lambda msg: True)
def handle_email(message):
    email = message.text.strip()
    bot.send_message(message.chat.id, "جاري إرسال رمز التحقق إلى البريد...")
    if not sendmil(email):
        bot.send_message(message.chat.id, "❌ فشل إرسال البريد للتحقق.")
        return

    msg_code = bot.send_message(message.chat.id, "الرجاء إدخال رمز التحقق الذي وصل إلى بريدك الإلكتروني:")
    bot.register_next_step_handler(msg_code, lambda m: handle_code(m, email))

def handle_code(message, email):
    code = message.text.strip()
    success, code_value = sendcod(email, code)
    if not success:
        bot.send_message(message.chat.id, "❌ الرمز غير صالح أو فشل التحقق.")
        return

    status, value = finsh(email, code_value)
    if not status:
        bot.send_message(message.chat.id, f"❌ فشل إنشاء الحساب: {value}")
        return

    username = value["username"]
    name = value["name"]
    password = value["password"]
    token = value["token"]
    session = value["session"]

    # رسالة نهائية مع أزرار
    mseg = f"""
*name: {name}*
*username:* `{username}`
*password:* `{password}`

*token:* `{token}`

*session:* `{session}`

"""
    markup = types.InlineKeyboardMarkup()
    btn1 = types.InlineKeyboardButton("مطور الأداة", url="https://t.me/b_azo")
    btn2 = types.InlineKeyboardButton("قناة المطور", url="https://t.me/bazok")
    markup.add(btn1, btn2)
    bot.send_message(message.chat.id, mseg, parse_mode='Markdown', reply_markup=markup)


bot.polling()

import requests,uuid,time,os,time,user_agent,random

def username(length=10):
    return ''.join(chr(random.randint(97, 122)) for _ in range(length))

def name():
    return f"شر - {random.randint(0, 9999)}"
    

def mid(_MID_FILE=".mid.txt"):
    if os.path.exists(_MID_FILE):
        with open(_MID_FILE, "r") as f:
            content = f.read().strip()
            if content:
                try:
                    stored_mid, timestamp = content.split("|")
                    timestamp = int(timestamp)
                    now_ms = int(time.time() * 1000)
                    if now_ms - timestamp < 12 * 60 * 60 * 1000:
                        return stored_mid
                except ValueError:
                    pass
    try:
        url = "https://www.instagram.com/api/graphql"
        headers = {'User-Agent': str(user_agent.generate_user_agent())}
        res = requests.get(url, headers=headers)
        if res.status_code != 200:
            raise Exception(f"error {res.status_code}")
        mid = None
        set_cookie = res.headers.get("Set-Cookie", "")
        if "mid=" in set_cookie:
            mid = set_cookie.split("mid=")[1].split(";")[0]
        if mid:
            now_ms = int(time.time() * 1000)
            with open(_MID_FILE, "w") as f:
                f.write(f"{mid}|{now_ms}")
        return mid
    except Exception as e:
        return f"Error: {e}"


def uu():
    return str(uuid.uuid4())
    
def tm():
    return str(f"{time.time():.3f}")

